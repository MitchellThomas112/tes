# Minecraft Real world generator (OpenStreetMap)

- 30k chunk/sec
- 1M chunks in 1 minute

## Run

```shell
git clone ...
cd ...
cargo run --release -- --help
```

1) Output in the folder : ./world
2) Before each generation : clear ./world/region/*